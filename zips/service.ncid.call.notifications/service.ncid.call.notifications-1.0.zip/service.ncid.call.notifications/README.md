xbmc.addon.call-notifications
=============================

*Call Notifications* does what the name says:
On incoming phone calls XBMC will show a notification.

The idea and parts of code are based on XBMC Yac Listener developed by @doug.

Since he won't update his code anymore I decided to code this thing as a weekend project.

Any feedback and contributions are welcome!

Features:
-----------------------------
 
 - Show Notification on incoming calls
 - Support for different CallerID clients/servers
 - Set Volume / Mute Volume / Pause Playback on incoming calls
 - Fully configurable through XBMC Gui
 - Reverse Search for telephone numbers


Client Support:
--------------------------------

 *  [Ncid](http://ncid.sourceforge.net/)  (Network Caller ID)

    Ncid seems to be the standard for unix based CallerID.
    It supports wide range of configurations.


What may be added?
-----------------------------

 * More Clients -> Ideas welcome
 * More Languages
 * CallLog

Credits
-------------------------------

 * doug (Orignal dev of the YAC script)
 * twisted
 * kodi Community
