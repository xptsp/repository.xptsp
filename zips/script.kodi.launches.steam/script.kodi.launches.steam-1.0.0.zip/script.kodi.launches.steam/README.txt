Kodi Launches Steam Addon

Description:
Addon for Kodi to launch Steam on Windows, Linux and MacOS.
Steam is the major online store for Windows, MacOS and Linux games and their related media.
It also offers multiplayer and cross-platform gaming, in-home streaming, cloud saving, in-game voice and chat,
achievements, VR, mods, hardware, devices and a huge and active gaming community. To install Steam, go to http://store.steampowered.com

A more detailed description of this Addon with instructions can be found here:
https://github.com/BrosMakingSoftware/Kodi-Launches-Steam-Addon/blob/master/README.md#kodi-launches-steam-addon

Source code: https://github.com/BrosMakingSoftware/Kodi-Launches-Steam-Addon
License: https://github.com/BrosMakingSoftware/Kodi-Launches-Steam-Addon/blob/master/LICENSE.md#license
