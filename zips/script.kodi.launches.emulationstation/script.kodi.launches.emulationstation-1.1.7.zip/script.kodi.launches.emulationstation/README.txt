Kodi Launches EmulationStation Addon

Description:
Addon for Kodi to launch EmulationStation on Windows and Linux.
EmulationStation is a cross-platform graphical front-end for emulators with controller navigation.
Install and configure EmulationStation before using this launcher, for instructions and downloads, go to http://emulationstation.org/

A more detailed description of this Addon with instructions can be found here
https://github.com/BrosMakingSoftware/Kodi-Launches-EmulationStation-Addon/blob/master/README.md#kodi-launches-emulationstation-addon

Source code: https://github.com/BrosMakingSoftware/Kodi-Launches-EmulationStation-Addon
License type: GNU GENERAL PUBLIC LICENSE Version 3, 29 June 2007
License link: https://github.com/BrosMakingSoftware/Kodi-Launches-EmulationStation-Addon/blob/master/LICENSE
Credits: https://github.com/BrosMakingSoftware/Kodi-Launches-EmulationStation-Addon/blob/master/CREDITS.md
